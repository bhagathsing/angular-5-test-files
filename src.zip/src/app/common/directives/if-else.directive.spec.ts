import { IfElseDirective } from './if-else.directive';

describe('IfElseDirective', () => {
  it('should create an instance', () => {
    const directive = new IfElseDirective();
    expect(directive).toBeTruthy();
  });
});
