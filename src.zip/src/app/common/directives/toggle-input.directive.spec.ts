import { ToggleInputDirective } from './toggle-input.directive';

describe('ToggleInputDirective', () => {
  it('should create an instance', () => {
    const directive = new ToggleInputDirective();
    expect(directive).toBeTruthy();
  });
});
