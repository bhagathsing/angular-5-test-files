export interface MenusData {
  name: string;
  url: string;
  id: number;
}
