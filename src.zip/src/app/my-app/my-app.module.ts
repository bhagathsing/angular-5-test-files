import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyAppComponent } from './my-app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import {MyAppRoutes} from './my-app.routings';
import {NavComponent} from '../common/pages/nav/nav.component';
import {AppHeaderComponent} from '../common/pages/app-header/app-header.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { DynamicComponent } from './dynamic/dynamic.component';
import { GridComponent } from './grid/grid.component';
import { FiltersComponent } from './filters/filters.component';
import {PageNotFoundComponent} from '../common/pages/page-not-found/page-not-found.component';
import { DirectivesComponent } from './directives/directives.component';
import {IfElseDirective} from '../common/directives/if-else.directive';
import {ToggleInputDirective} from '../common/directives/toggle-input.directive';
@NgModule({
  imports: [
    CommonModule,
    MyAppRoutes,
    BsDropdownModule.forRoot()
  ],
  declarations: [
    MyAppComponent,
    DashboardComponent,
    NavComponent,
    AppHeaderComponent,
    DynamicComponent,
    GridComponent,
    FiltersComponent,
    PageNotFoundComponent,
    DirectivesComponent,
    IfElseDirective,
    ToggleInputDirective
  ],
  exports: [
    PageNotFoundComponent
  ]
})
export class MyAppModule { }
