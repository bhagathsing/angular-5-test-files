import { Injectable } from '@angular/core';

import { find } from 'lodash';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/map';
import {HttpClient} from '@angular/common/http';
import {HttpClientAPI} from './HttpClient';


@Injectable()
export class LiveDataService extends HttpClientAPI {

    private readonly basePath = 'http://10.250.71.12:9222/'; // This is for local // http://172.16.28.51:8111
    private readonly MyTrUrl = 'mytr/';
    private readonly userDataUrl = 'userData.json';
    public UserData: any = {};

    private readonly REQUEST_HEADERS: Headers = new Headers({
        'Content-Type': 'application/json; charset=utf-8',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
    });

    private getBaseURI() {
       return this.basePath +  this.MyTrUrl;
    }

    constructor(http: HttpClient) {
      super( http );
    }
    public getUserData(): Observable<any> {
      return this.get(this.userDataUrl);
    }
    public gruopBy(value: any[], field: any): Array<any> {
        const groupedObj = value.reduce((prev, cur) => {
            if (!prev[cur[field]]) {
                prev[cur[field]] = [cur];
              } else {
                prev[cur[field]].push(cur);

              }
          return prev;
        }, {});
        return Object.keys(groupedObj).map(key =>{
            return { key, value: groupedObj[key] }
        });
    }
    public mapData( data: any[]) {
        const arr = [];

        data.forEach(( obj, ind ) => {
            arr.push({
                department: obj.key,
                totalEmployee: obj.value.length,
                salaried: obj.value.filter( o => o['2602057'].toLowerCase() === 's').length,
                hourly: obj.value.filter( o => o['2602057'].toLowerCase() === 'h').length
            });
        });

        return arr;
    }

    public count( arr,prop ) {
        let obj = {};
        arr.sort((a, b)=>{
            var x = a[prop].toLowerCase(), y = b[prop].toLowerCase();
            if ( x < y )
                return -1;
            if ( x > y )
                return 1;
            return 0;
        });

        var current = null;
        var cnt = 0;
        for (var i = 0; i < arr.length; i++) {
            if (arr[i][prop] != current) {
                if (cnt > 0) {
                    obj[current] = cnt;
                }
                current = arr[i][prop];
                cnt = 1;
            } else {
                cnt++;
            }
        }
        if (cnt > 0) {
            obj[current] = cnt;
        }
        return obj;
    }

}

